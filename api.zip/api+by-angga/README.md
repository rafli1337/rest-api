
![APRILIYA-API](https://telegra.ph/file/c793578cfabf67d292dd0.png)
# APRILIYA - AAPI's
<p align="center">
<a href="https://github.com/LoliKillers/Apriliya-Api/network/members" alt="GitHub stars"> <img src="https://img.shields.io/github/stars/LoliKillers/Apriliya-Api?style=flat&logo=github&color=yellow" /> </a>
<a href="https://github.com/LoliKillers/Apriliya-Api/network/members" alt="GitHub forks"> <img src="https://img.shields.io/github/forks/LoliKillers/Apriliya-Api" /> </a>
</p>
<p align="center">
<a href="https://github.com/LoliKillers/Apriliya-Api" alt="GitHub commit activity"> <img src="https://img.shields.io/github/commit-activity/m/LoliKillers/Apriliya-Api" /> </a>
<a href="https://github.com/LoliKillers/Apriliya-Api/graphs/contributors" alt="GitHub contributors"> <img src="https://img.shields.io/github/contributors/LoliKillers/Apriliya-Api?style=flat&logo=github" /> </a>
<a href="https://github.com/LoliKillers/Apriliya-Api" alt="GitHub closed pull requests"> <img src="https://img.shields.io/github/issues-pr-closed-raw/LoliKillers/Apriliya-Api?color=success" /> </a>
<a href="https://github.com/LoliKillers/Apriliya-Api" alt="GitHub issues"> <img src="https://img.shields.io/github/issues-raw/LoliKillers/Apriliya-Api?style=flat&logo=github&color=red" /> </a>
<a href="https://github.com/LoliKillers/Apriliya-Api" alt="GitHub closed issues"> <img src="https://img.shields.io/github/issues-closed-raw/LoliKillers/Apriliya-Api?style=flat&logo=github&color=success" /> </a>
</p>
<p align="center">
<a href="https://github.com/LoliKillers/Apriliya-Api" alt="GitHub repo size"> <img src="https://img.shields.io/github/repo-size/LoliKillers/Apriliya-Api" /> </a>
<a href="https://github.com/LoliKillers/Apriliya-Api/blob/master/LICENSE" alt="GPLv3 license"> <img src="https://img.shields.io/github/license/LoliKillers/Apriliya-Api?style=flat&logo=github&color=success" /> </a>
</p>
<p align="center">
<a href="" alt="LoliKillers"> <img src="https://img.shields.io/badge/built%20by-LoliKillers-blue" /> </a>
<a href="https://github.com/LoliKillers/Apriliya-Api/graphs/commit-activity" alt="Maintenance"> <img src="https://img.shields.io/badge/maintained%3F-yes-blue.svg" /> </a>
<a href="https://makeapullrequest.com" alt="PRs Welcome"> <img src="https://img.shields.io/badge/PRs-welcome-blue.svg" /> </a>
</p>

## APRILIYA Rest Api

Repository ini saya buat hanya untuk membantu mereka yang ingin memiliki rest api website sendiri

## How To Self Host
```bash

```

## How To Deploy Heroku

Lihat [disini](https://t.me/Arnz_Official/4)


## Note
- Project ini open source
- Tidak untuk di perjual belikan
